## Result

 `curl https://{{host}}.execute-api.us-west-2.amazonaws.com/dev/ping`
 
 Pong!%
 
 wscat -c wss://{{your-host}}.execute-api.us-west-2.amazonaws.com/dev
 
 <img width="248" alt="스크린샷 2023-04-04 오후 5 39 50" src="https://user-images.githubusercontent.com/72637095/229736949-96235273-abd0-4c0e-8c69-002d5015e09e.png">
