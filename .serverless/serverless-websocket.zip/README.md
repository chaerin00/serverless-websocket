## Result

 `curl https://{{host}}.execute-api.us-west-2.amazonaws.com/dev/ping`
 
 Pong!%
 
 wscat -c wss://{{your-host}}.execute-api.us-west-2.amazonaws.com/dev
 

<img width="483" alt="스크린샷 2023-04-04 오후 7 47 42" src="https://user-images.githubusercontent.com/72637095/229769166-b656a1e0-8c67-4179-a625-5c5756d27081.png">
